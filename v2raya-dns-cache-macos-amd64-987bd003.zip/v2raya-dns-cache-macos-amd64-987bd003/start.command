#!/bin/bash
set -euo pipefail
package_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
cd "$package_dir"
config_dir="${V2RAYA_TEST_CONFIG:-$HOME/Library/Application Support/v2raya-dns-cache-test-987bd003}"
printf 'v2rayA DNS 缓存测试包\n配置目录：%s\n浏览器地址：http://127.0.0.1:2017\n按 Ctrl+C 停止。\n' "$config_dir"
exec "$package_dir/v2raya" \
  --lite \
  --address 127.0.0.1:2017 \
  --config "$config_dir" \
  --v2ray-bin "$package_dir/v2raya_core" \
  --v2ray-assetsdir "$package_dir/assets"
