package coreObj

import (
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"
	"time"
)

// PinnedPeerCertSha256Hex normalizes a peer certificate pin value found in an
// imported link into the hex string that xray-core's "pinnedPeerCertSha256"
// field expects (comma-separated lowercase hex, 64 chars each).
//
// Link formats disagree about the pin representation:
//   - xray/v2rayN style: base64 of the SHA256 hash
//   - sing-box / hysteria2 style: hex string of the SHA256 hash
//   - some formats may include an optional "sha256:" prefix
//   - openssl-style pins may separate octets with colons (AB:CD:EF:...)
//   - multiple pins may be joined with commas
//
// An empty input yields ("", nil). A non-empty pin that cannot be normalized
// returns an error so a silently dropped pin never downgrades verification.
func PinnedPeerCertSha256Hex(pin string) (string, error) {
	pin = strings.TrimSpace(pin)
	if pin == "" {
		return "", nil
	}
	var out []string
	for _, part := range strings.Split(pin, ",") {
		part = strings.TrimSpace(part)
		part = strings.TrimPrefix(part, "sha256:")
		part = strings.TrimPrefix(part, "SHA256:")
		// Strip openssl-style colons: AB:CD:EF:...
		part = strings.ReplaceAll(part, ":", "")
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		// Try hex (32 bytes = 64 hex chars).
		if raw, err := hex.DecodeString(part); err == nil && len(raw) == 32 {
			out = append(out, hex.EncodeToString(raw))
			continue
		}
		// Try base64 / base64url, with or without padding.
		var raw []byte
		matched := false
		for _, dec := range []*base64.Encoding{
			base64.StdEncoding,
			base64.RawStdEncoding,
			base64.URLEncoding,
			base64.RawURLEncoding,
		} {
			if decoded, err := dec.DecodeString(part); err == nil && len(decoded) == 32 {
				raw = decoded
				matched = true
				break
			}
		}
		if !matched {
			return "", fmt.Errorf("unrecognized peer certificate pin: %q", pin)
		}
		out = append(out, hex.EncodeToString(raw))
	}
	return strings.Join(out, ","), nil
}

type APIObject struct {
	Tag      string   `json:"tag"`
	Services []string `json:"services"`
}
type MultiObservatory struct {
	Observers []ObservatoryItem `json:"observers"`
}
type ObservatoryItem struct {
	Tag      string      `json:"tag"`
	Settings Observatory `json:"settings"`
}
type Observatory struct {
	SubjectSelector []string    `json:"subjectSelector"`
	PingConfig      *PingConfig `json:"pingConfig,omitempty"`
	ProbeURL        string      `json:"probeURL,omitempty"`
	ProbeInterval   string      `json:"probeInterval,omitempty"`
}

type PingConfig struct {
	Destination   string `json:"destination,omitempty"`
	Connectivity  string `json:"connectivity,omitempty"`
	Interval      string `json:"interval,omitempty"`
	SamplingCount int    `json:"samplingCount,omitempty"`
	Timeout       string `json:"timeout,omitempty"`
	HTTPMethod    string `json:"httpMethod,omitempty"`
}
type Balancer struct {
	Tag      string           `json:"tag"`
	Selector []string         `json:"selector"`
	Strategy BalancerStrategy `json:"strategy"`
}
type BalancerStrategy struct {
	Type     string            `json:"type"`
	Settings *StrategySettings `json:"settings,omitempty"`
}
type StrategySettings struct {
	ObserverTag string `json:"observerTag"`
}
type FakeDns struct {
	IpPool   string `json:"ipPool"`
	PoolSize int    `json:"poolSize"`
}
type RoutingRule struct {
	Type        string   `json:"type"`
	OutboundTag string   `json:"outboundTag,omitempty"`
	BalancerTag string   `json:"balancerTag,omitempty"`
	InboundTag  []string `json:"inboundTag,omitempty"`
	Domain      []string `json:"domain,omitempty"`
	IP          []string `json:"ip,omitempty"`
	Network     string   `json:"network,omitempty"`
	Port        string   `json:"port,omitempty"`
	SourcePort  string   `json:"sourcePort,omitempty"`
	Protocol    []string `json:"protocol,omitempty"`
	Source      []string `json:"source,omitempty"`
	User        []string `json:"user,omitempty"`
}
type Log struct {
	Access   string `json:"access"`
	Error    string `json:"error"`
	Loglevel string `json:"loglevel"`
}
type Sniffing struct {
	Enabled         bool     `json:"enabled"`
	DestOverride    []string `json:"destOverride,omitempty"`
	MetadataOnly    bool     `json:"metadataOnly"`
	DomainsExcluded []string `json:"domainsExcluded"`
	RouteOnly       bool     `json:"routeOnly"`
}
type Inbound struct {
	Port           int              `json:"port"`
	Protocol       string           `json:"protocol"`
	Listen         string           `json:"listen,omitempty"`
	Sniffing       Sniffing         `json:"sniffing,omitempty"`
	Settings       *InboundSettings `json:"settings,omitempty"`
	StreamSettings *StreamSettings  `json:"streamSettings"`
	Tag            string           `json:"tag,omitempty"`
}
type InboundSettings struct {
	Auth           string      `json:"auth,omitempty"`
	UDP            bool        `json:"udp,omitempty"`
	IP             interface{} `json:"ip,omitempty"`
	Accounts       []Account   `json:"accounts,omitempty"`
	Clients        interface{} `json:"clients,omitempty"`
	Decryption     string      `json:"decryption,omitempty"`
	Network        string      `json:"network,omitempty"`
	UserLevel      int         `json:"userLevel,omitempty"`
	Address        string      `json:"address,omitempty"`
	Port           int         `json:"port,omitempty"`
	FollowRedirect bool        `json:"followRedirect,omitempty"`
	// tun-mips inbound (the built-in TUN); see core/hint/proxy/tunmips.
	Name             string   `json:"name,omitempty"`
	MTU              uint32   `json:"mtu,omitempty"`
	Address4         string   `json:"address4,omitempty"`
	Address6         string   `json:"address6,omitempty"`
	DnsTarget        string   `json:"dnsTarget,omitempty"`
	ExcludeProcesses []string `json:"excludeProcesses,omitempty"`
	SelfPids         []uint32 `json:"selfPids,omitempty"`
	DirectTag        string   `json:"directTag,omitempty"`
}
type VlessClient struct {
	Id    string `json:"id"`
	Level int    `json:"level,omitempty"`
	Email string `json:"email,omitempty"`
}
type Account struct {
	User string `json:"user"`
	Pass string `json:"pass"`
}
type User struct {
	ID         string `json:"id"`
	AlterID    int    `json:"alterId,omitempty"`
	Encryption string `json:"encryption,omitempty"`
	Flow       string `json:"flow,omitempty"`
	Security   string `json:"security,omitempty"`
	Level      int    `json:"level,omitempty"`
}
type Vnext struct {
	Address string `json:"address"`
	Port    int    `json:"port"`
	Users   []User `json:"users"`
}
type Server struct {
	Network  string         `json:"network,omitempty"`
	Address  string         `json:"address,omitempty"`
	Method   string         `json:"method,omitempty"`
	Ota      bool           `json:"ota,omitempty"`
	Password string         `json:"password,omitempty"`
	Port     int            `json:"port,omitempty"`
	Users    []OutboundUser `json:"users,omitempty"`
}
type Settings struct {
	Vnext          interface{} `json:"vnext,omitempty"`
	Servers        interface{} `json:"servers,omitempty"`
	DomainStrategy string      `json:"domainStrategy,omitempty"`
	Port           int         `json:"port,omitempty"`
	Address        string      `json:"address,omitempty"`
	Network        string      `json:"network,omitempty"`
	Redirect       string      `json:"redirect,omitempty"`
	UserLevel      *int        `json:"userLevel,omitempty"`
	// Inlined, when non-nil, replaces the entire settings JSON during serialization.
	// Used for non-standard protocols such as anytls/juicity whose settings do not
	// fit the standard fields above.
	Inlined json.RawMessage `json:"-"`
}

// MarshalJSON implements json.Marshaler. When Inlined is set it is emitted verbatim;
// otherwise normal struct marshaling is used.
func (s Settings) MarshalJSON() ([]byte, error) {
	if s.Inlined != nil {
		return s.Inlined, nil
	}
	type Alias Settings
	return json.Marshal(Alias(s))
}

type TLSSettings struct {
	ServerName interface{} `json:"serverName,omitempty"`
	Alpn       []string    `json:"alpn,omitempty"`
	// PinnedPeerCertSha256 pins the peer certificate by the SHA256 hash of its
	// DER-encoded leaf certificate (or a CA certificate within its chain).
	// xray-core expects a comma-separated hex string. Use PinnedPeerCertSha256Hex()
	// to build this from the value found in imported links (which may be hex or
	// base64).
	PinnedPeerCertSha256 string        `json:"pinnedPeerCertSha256,omitempty"`
	VerifyPeerCertByName string        `json:"verifyPeerCertByName,omitempty"`
	Certificates         []Certificate `json:"certificates,omitempty"`
	Fingerprint          string        `json:"fingerprint,omitempty"`
}
type Certificate struct {
	CertificateFile string `json:"certificateFile"`
	KeyFile         string `json:"keyFile"`
}
type Headers struct {
	Host string `json:"Host"`
}
type WsSettings struct {
	Path                string  `json:"path"`
	Headers             Headers `json:"headers"`
	MaxEarlyData        int     `json:"maxEarlyData,omitempty"`
	EarlyDataHeaderName string  `json:"earlyDataHeaderName,omitempty"`
}
type StreamSettings struct {
	Network          string            `json:"network,omitempty"`
	Security         string            `json:"security,omitempty"`
	TLSSettings      *TLSSettings      `json:"tlsSettings,omitempty"`
	XTLSSettings     *TLSSettings      `json:"xtlsSettings,omitempty"`
	XHTTPSettings    *XHTTPSettings    `json:"xhttpSettings,omitempty"`
	RealitySettings  *RealitySettings  `json:"realitySettings,omitempty"`
	TCPSettings      *TCPSettings      `json:"tcpSettings,omitempty"`
	KcpSettings      *KcpSettings      `json:"kcpSettings,omitempty"`
	WsSettings       *WsSettings       `json:"wsSettings,omitempty"`
	HTTPSettings     *HttpSettings     `json:"httpSettings,omitempty"`
	GrpcSettings     *GrpcSettings     `json:"grpcSettings,omitempty"`
	QuicSettings     *QuicSettings     `json:"quicSettings,omitempty"`
	HysteriaSettings *HysteriaSettings `json:"hysteriaSettings,omitempty"`
	FinalMask        *FinalMask        `json:"finalmask,omitempty"`
	Sockopt          *Sockopt          `json:"sockopt,omitempty"`
}
type HysteriaSettings struct {
	Version int32  `json:"version"`
	Auth    string `json:"auth,omitempty"`
}
type FinalMask struct {
	Udp []UdpMask `json:"udp,omitempty"`
}
type UdpMask struct {
	Type     string          `json:"type"`
	Settings json.RawMessage `json:"settings,omitempty"`
}
type RealitySettings struct {
	ServerName  string `json:"serverName,omitempty"`
	Fingerprint string `json:"fingerprint,omitempty"`
	Show        bool   `json:"show,omitempty"`
	PublicKey   string `json:"publicKey,omitempty"`
	ShortID     string `json:"shortId,omitempty"`
	SpiderX     string `json:"spiderX,omitempty"`
}
type GrpcSettings struct {
	ServiceName         string `json:"serviceName"`
	MultiMode           bool   `json:"multiMode,omitempty"`
	IdleTimeout         int    `json:"idle_timeout,omitempty"`
	HealthCheckTimeout  int    `json:"health_check_timeout,omitempty"`
	PermitWithoutStream bool   `json:"permit_without_stream,omitempty"`
	InitialWindowsSize  int    `json:"initial_windows_size,omitempty"`
}
type Sockopt struct {
	Mark        *int    `json:"mark,omitempty"`
	Interface   string  `json:"interface,omitempty"`
	Tos         *int    `json:"tos,omitempty"`
	TCPFastOpen *bool   `json:"tcpFastOpen,omitempty"`
	Tproxy      *string `json:"tproxy,omitempty"`
}
type Mux struct {
	Enabled     bool `json:"enabled"`
	Concurrency int  `json:"concurrency"`
}
type OutboundObject struct {
	Tag            string          `json:"tag"`
	Protocol       string          `json:"protocol"`
	SendThrough    string          `json:"sendThrough,omitempty"`
	Settings       Settings        `json:"settings,omitempty"`
	StreamSettings *StreamSettings `json:"streamSettings,omitempty"`
	ProxySettings  *ProxySettings  `json:"proxySettings,omitempty"`
	Mux            *Mux            `json:"mux,omitempty"`
	Balancers      []string        `json:"-"`
}
type OutboundUser struct {
	User  string `json:"user"`
	Pass  string `json:"pass"`
	Level int    `json:"level,omitempty"`
}
type ProxySettings struct {
	Tag string `json:"tag,omitempty"`
}
type TCPSettings struct {
	ConnectionReuse bool      `json:"connectionReuse"`
	Header          TCPHeader `json:"header"`
}
type HTTPRequest struct {
	Version string        `json:"version"`
	Method  string        `json:"method"`
	Path    []string      `json:"path"`
	Headers HTTPReqHeader `json:"headers"`
}
type HTTPReqHeader struct {
	Host           []string `json:"Host"`
	UserAgent      []string `json:"User-Agent"`
	AcceptEncoding []string `json:"Accept-Encoding"`
	Connection     []string `json:"Connection"`
	Pragma         string   `json:"Pragma"`
}
type HTTPResponse struct {
	Version string         `json:"version"`
	Status  string         `json:"status"`
	Reason  string         `json:"reason"`
	Headers HTTPRespHeader `json:"headers"`
}
type HTTPRespHeader struct {
	ContentType      []string `json:"Content-Type"`
	TransferEncoding []string `json:"Transfer-Encoding"`
	Connection       []string `json:"Connection"`
	Pragma           string   `json:"Pragma"`
}
type TCPHeader struct {
	Type     string       `json:"type"`
	Request  HTTPRequest  `json:"request"`
	Response HTTPResponse `json:"response"`
}
type KcpSettings struct {
	Mtu              int       `json:"mtu"`
	Tti              int       `json:"tti"`
	UplinkCapacity   int       `json:"uplinkCapacity"`
	DownlinkCapacity int       `json:"downlinkCapacity"`
	Congestion       bool      `json:"congestion"`
	ReadBufferSize   int       `json:"readBufferSize"`
	WriteBufferSize  int       `json:"writeBufferSize"`
	Header           KcpHeader `json:"header"`
	Seed             string    `json:"seed,omitempty"`
}
type KcpHeader struct {
	Type     string      `json:"type"`
	Request  interface{} `json:"request"`
	Response interface{} `json:"response"`
}
type HttpSettings struct {
	Path   string   `json:"path"`
	Host   []string `json:"host,omitempty"`
	Method string   `json:"method,omitempty"`
}
type QuicSettings struct {
	Header   KcpHeader `json:"header"`
	Key      string    `json:"key,omitempty"`
	Security string    `json:"security"`
}
type XHTTPRangeConfig struct {
	From int32 `json:"from,omitempty"`
	To   int32 `json:"to,omitempty"`
}

// MarshalJSON emits the shorthand xray-core accepts for splithttp range
// fields: a plain integer when From equals To, an "a-b" string otherwise.
// The core's Int32Range unmarshaler rejects the object form this struct
// would otherwise serialize to, so the default marshaling must not be used.
func (r XHTTPRangeConfig) MarshalJSON() ([]byte, error) {
	if r.From == r.To {
		return []byte(strconv.FormatInt(int64(r.From), 10)), nil
	}
	return json.Marshal(fmt.Sprintf("%d-%d", r.From, r.To))
}

// UnmarshalJSON accepts the plain-integer and "a-b" string forms the core
// accepts, so generated configs round-trip.
func (r *XHTTPRangeConfig) UnmarshalJSON(data []byte) error {
	var str string
	if err := json.Unmarshal(data, &str); err == nil {
		from, to, err := ParseRangeString(str)
		if err != nil {
			return err
		}
		r.From, r.To = int32(from), int32(to)
		return nil
	}
	var num int32
	if err := json.Unmarshal(data, &num); err == nil {
		r.From, r.To = num, num
		return nil
	}
	return fmt.Errorf("invalid integer range %s: expected an integer or a string of form \"a-b\"", data)
}

// ParseRangeString mirrors xray-core's ParseRangeString, which supports
// negative endpoints such as "-114-514" and "-1919--810". Links from other
// clients (3x-ui packs its XHTTP ranges here) send the values in these same
// two forms, so they parse with the same rules.
func ParseRangeString(str string) (int, int, error) {
	if value, err := strconv.Atoi(str); err == nil {
		return value, value, nil
	}
	if str == "" {
		return 0, 0, nil
	}
	var pair []string
	if strings.HasPrefix(str, "-") {
		parts := strings.SplitN(str, "-", 3)
		if len(parts) < 3 {
			return 0, 0, fmt.Errorf("invalid range string: %s", str)
		}
		pair = []string{parts[0] + "-" + parts[1], parts[2]}
	} else {
		pair = strings.SplitN(str, "-", 2)
	}
	if len(pair) == 2 {
		left, err := strconv.Atoi(pair[0])
		right, err2 := strconv.Atoi(pair[1])
		if err == nil && err2 == nil {
			return left, right, nil
		}
	}
	return 0, 0, fmt.Errorf("invalid range string: %s", str)
}

type XHTTPXmux struct {
	MaxConcurrency   *XHTTPRangeConfig `json:"maxConcurrency,omitempty"`
	MaxConnections   *XHTTPRangeConfig `json:"maxConnections,omitempty"`
	CMaxReuseTimes   *XHTTPRangeConfig `json:"cMaxReuseTimes,omitempty"`
	HMaxRequestTimes *XHTTPRangeConfig `json:"hMaxRequestTimes,omitempty"`
	HMaxReusableSecs *XHTTPRangeConfig `json:"hMaxReusableSecs,omitempty"`
	HKeepAlivePeriod int64             `json:"hKeepAlivePeriod,omitempty"`
}

type XHTTPSettings struct {
	Path                 string            `json:"path,omitempty"`
	Host                 string            `json:"host,omitempty"`
	Mode                 string            `json:"mode,omitempty"`
	Headers              map[string]string `json:"headers,omitempty"`
	XPaddingBytes        *XHTTPRangeConfig `json:"xPaddingBytes,omitempty"`
	XPaddingObfsMode     bool              `json:"xPaddingObfsMode,omitempty"`
	XPaddingKey          string            `json:"xPaddingKey,omitempty"`
	XPaddingHeader       string            `json:"xPaddingHeader,omitempty"`
	XPaddingPlacement    string            `json:"xPaddingPlacement,omitempty"`
	XPaddingMethod       string            `json:"xPaddingMethod,omitempty"`
	NoGRPCHeader         bool              `json:"noGRPCHeader,omitempty"`
	NoSSEHeader          bool              `json:"noSSEHeader,omitempty"`
	ScMaxEachPostBytes   *XHTTPRangeConfig `json:"scMaxEachPostBytes,omitempty"`
	ScMinPostsIntervalMs *XHTTPRangeConfig `json:"scMinPostsIntervalMs,omitempty"`
	ScMaxBufferedPosts   int64             `json:"scMaxBufferedPosts,omitempty"`
	ScStreamUpServerSecs *XHTTPRangeConfig `json:"scStreamUpServerSecs,omitempty"`
	Xmux                 *XHTTPXmux        `json:"xmux,omitempty"`
	UplinkHTTPMethod     string            `json:"uplinkHTTPMethod,omitempty"`
}

// WireGuard 出站配置
type WireGuardSettings struct {
	SecretKey  string          `json:"secretKey"`
	Address    []string        `json:"address"`
	Workers    int             `json:"workers,omitempty"`
	Mtu        int             `json:"mtu,omitempty"`
	Reserved   []int           `json:"reserved,omitempty"`
	Peers      []WireGuardPeer `json:"peers"`
	KernelMode bool            `json:"kernelMode,omitempty"`
}

type WireGuardPeer struct {
	Endpoint     string   `json:"endpoint"`
	PublicKey    string   `json:"publicKey"`
	PreSharedKey string   `json:"preSharedKey,omitempty"`
	AllowedIPs   []string `json:"allowedIPs"`
	KeepAlive    int      `json:"keepAlive,omitempty"`
}

type Hosts map[string][]string

type DNS struct {
	Hosts           Hosts         `json:"hosts,omitempty"`
	Servers         []interface{} `json:"servers"`
	ClientIp        string        `json:"clientIp,omitempty"`
	Tag             string        `json:"tag,omitempty"`
	DisableFallback *bool         `json:"disableFallback,omitempty"`
	QueryStrategy   string        `json:"queryStrategy,omitempty"`
}
type DnsServer struct {
	Address      string   `json:"address"`
	Port         int      `json:"port,omitempty"`
	Domains      []string `json:"domains,omitempty"`
	SkipFallback bool     `json:"skipFallback,omitempty"`
}
type Policy struct {
	Levels struct {
		Num0 struct {
			Handshake         int  `json:"handshake,omitempty"`
			ConnIdle          int  `json:"connIdle,omitempty"`
			UplinkOnly        int  `json:"uplinkOnly,omitempty"`
			DownlinkOnly      int  `json:"downlinkOnly,omitempty"`
			StatsUserUplink   bool `json:"statsUserUplink,omitempty"`
			StatsUserDownlink bool `json:"statsUserDownlink,omitempty"`
			BufferSize        int  `json:"bufferSize,omitempty"`
		} `json:"0"`
	} `json:"levels"`
	System struct {
		StatsInboundUplink    bool `json:"statsInboundUplink,omitempty"`
		StatsInboundDownlink  bool `json:"statsInboundDownlink,omitempty"`
		StatsOutboundUplink   bool `json:"statsOutboundUplink,omitempty"`
		StatsOutboundDownlink bool `json:"statsOutboundDownlink,omitempty"`
	} `json:"system"`
}

// DnsModuleStatus 表示新 DNS 模块的运行状态，用于 API 报告。
type DnsModuleStatus struct {
	Healthy       bool             `json:"healthy"`
	ListenAddr    string           `json:"listenAddr"`
	TotalQueries  int64            `json:"totalQueries"`
	RejectedQuery int64            `json:"rejectedQueries"`
	BypassedQuery int64            `json:"bypassedQueries"`
	CacheHits     int64            `json:"cacheHits"`
	CacheMisses   int64            `json:"cacheMisses"`
	AvgRTT        time.Duration    `json:"avgRtt"`
	RoutedQueries map[string]int64 `json:"routedQueries"`
	NumRules      int              `json:"numRules"`
	NumUpstreams  int              `json:"numUpstreams"`
}
